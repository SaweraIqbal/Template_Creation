import React from 'react'

const HomePage = () => {
  return (
    <div>
      Welcome to Home Page
    </div>
  )
}

export default HomePage
