import React from 'react'

const Setting = () => {
  return (
    <div>
      Change your Settings
    </div>
  )
}

export default Setting
