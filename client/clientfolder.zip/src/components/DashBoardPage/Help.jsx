import React from 'react'

const Help = () => {
  return (
    <div>
      Help Center
    </div>
  )
}

export default Help
