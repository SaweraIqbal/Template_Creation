import React from 'react'

const Projects = () => {
  return (
    <div>
      Project page
    </div>
  )
}

export default Projects
